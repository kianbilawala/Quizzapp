package com.example.myquizapplication;

public class QuestionAnswer {

    public static String question[] ={
            "Which company owns the android?",
            "Which one is not the programming language?",
            "When is term end exam starting?",
            "Which company owns the Dior?"
    };

    public static String choices[][] = {
            {"Google","Apple","Nokia","Samsung"},
            {"Java","Kotlin","Notepad","Python"},
            {"13th April","12th April","17th April","15th April"},
            {"Gucci","Armani","Zara","LVMH"}
    };

    public static String correctAnswers[] = {
            "Google",
            "Notepad",
            "17th April",
            "LVMH"
    };

}
